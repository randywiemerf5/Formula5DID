param(
    [string]$ResourceGroupName,
    [string]$RelayNamespace,
    [string]$HybridConnName,
    [string]$WebAppName,
    [string]$RelayName
)

$hc = Get-AzRelayHybridConnection -ResourceGroupName $ResourceGroupName -NamespaceName $RelayNamespace -Name $HybridConnName -ErrorAction SilentlyContinue
if (-not $hc) {
    Write-Host "Creating Hybrid Connection..."
    New-AzRelayHybridConnection -ResourceGroupName $ResourceGroupName `
        -NamespaceName $RelayNamespace `
        -Name $HybridConnName `
        -RelayName $RelayName
}

Write-Host "Linking Hybrid Connection to Web App..."
Set-AzWebAppHybridConnection -ResourceGroupName $ResourceGroupName `
    -WebAppName $WebAppName `
    -HybridConnectionName $HybridConnName
