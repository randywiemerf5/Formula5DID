param(
    [string]$ResourceGroupName,
    [string]$Location,
    [string]$AppServicePlanName,
    [string]$Sku = "P1v3"
)

$plan = Get-AzAppServicePlan -Name $AppServicePlanName -ResourceGroupName $ResourceGroupName -ErrorAction SilentlyContinue
if (-not $plan) {
    Write-Host "Creating App Service Plan..."
    New-AzAppServicePlan -Name $AppServicePlanName `
        -ResourceGroupName $ResourceGroupName `
        -Location $Location `
        -Tier "PremiumV3" `
        -WorkerSize "Small"
} else {
    Write-Host "App Service Plan already exists."
}
