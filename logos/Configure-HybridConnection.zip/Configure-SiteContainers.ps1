param(
    [string]$ResourceGroupName,
    [string]$WebAppName,
    [string]$ImageName,
    [string]$RegistryUrl,
    [string]$RegistryUser,
    [string]$RegistryPassword
)

Write-Host "Configuring container settings..."
Set-AzWebApp -Name $WebAppName `
    -ResourceGroupName $ResourceGroupName `
    -ContainerImageName $ImageName `
    -ContainerRegistryUrl $RegistryUrl `
    -ContainerRegistryUser $RegistryUser `
    -ContainerRegistryPassword (ConvertTo-SecureString $RegistryPassword -AsPlainText -Force)
