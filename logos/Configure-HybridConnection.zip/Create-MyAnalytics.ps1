param(
    [string]$ResourceGroupName,
    [string]$Location,
    [string]$AppInsightsName
)

$ai = Get-AzApplicationInsights -ResourceGroupName $ResourceGroupName -Name $AppInsightsName -ErrorAction SilentlyContinue
if (-not $ai) {
    Write-Host "Creating Application Insights..."
    New-AzApplicationInsights -ResourceGroupName $ResourceGroupName `
        -Name $AppInsightsName `
        -Location $Location `
        -Kind "web"
} else {
    Write-Host "Application Insights already exists."
}
