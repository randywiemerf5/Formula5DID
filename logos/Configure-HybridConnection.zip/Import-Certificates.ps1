param(
    [string]$ResourceGroupName,
    [string]$WebAppName,
    [string]$CertPath,
    [string]$CertPassword
)

$certName = [System.IO.Path]::GetFileNameWithoutExtension($CertPath)
$cert = Get-AzWebAppSSLBinding -ResourceGroupName $ResourceGroupName -WebAppName $WebAppName -ErrorAction SilentlyContinue
if (-not $cert) {
    Write-Host "Importing certificate..."
    New-AzWebAppSSLBinding -ResourceGroupName $ResourceGroupName `
        -WebAppName $WebAppName `
        -Name $certName `
        -CertificateFilePath $CertPath `
        -CertificatePassword (ConvertTo-SecureString $CertPassword -AsPlainText -Force)
} else {
    Write-Host "Certificate already bound."
}
